#!/bin/bash

set -e
# To updates the local list of packages
sudo apt-get update

# To upgrade all the packages of the system to the most recent version
sudo apt-get upgrade

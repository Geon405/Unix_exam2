#!/bin/bash

# List of the users
echo "The users in the system are\n $(cut -d: -f1 /etc/passwd)"

# Total number of the users
echo "The total number of users are $(getent passwd | cut -d: -f1)"

# To get the information of the users
userid=$(getent passwd | grep '/home' | cut -d: -f1)
for user in $userids
do
	id $user
done

#!/bin/python

import re

validIp1 = "192.168.2.1"
validIp2 = "200.8.233.27"
validIp3 = "1.1.1.1"

invalidIp1 = "aa.3.4.5"
invalidIp2 = "4.5.6"

regex = "^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$"

if re.search(regex, validIp1):
    print validIp1 + " is valid ip address"

if re.search(regex, validIp2):
    print validIp2 + " is valid ip address"

if re.search(regex, validIp3):
    print validIp3 + " is valid ip address"

if re.search(regex, invalidIp1):
    print invalidIp1 + " is invalid ip address"
 
if re.search(regex, invalidIp2):
    print invalidIp2 + " is invalid ip address"
